<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel app\models\DiparealisasiSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Realisasi Dipa';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="dipa-index">
    <div class="box box-solid box-primary">
        <div class="box-header with-border">
            <h4 class="box-title">Realisasi<?php // echo $this->title;  ?></h4>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-lg-11">
                    <div class="input-group">
                    </div><!-- /input-group -->
                </div><!-- /.col-lg-6 -->
                <div class="col-lg-1">
                </div><!-- /.col-lg-6 -->
            </div><!-- /.row -->
        </div>
        <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>
        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
//            'filterModel' => $searchModel,
            'bordered' => true,
            'striped' => true,
            'condensed' => true,
            'responsive' => true,
            'formatter' => ['class' => 'yii\i18n\Formatter', 'nullDisplay' => ''],
            'hover' => true,
            'toolbar' => [
                    ['content' =>
                    Html::a('<i class = "glyphicon glyphicon-repeat"></i>', Url::toRoute([]), ['data-pjax' => 0, 'class' => 'btn btn-default', 'title' => Yii::t('kvgrid', 'Reset Grid')])
                ],
                '{export}',
                '{toggleData}',
            ],
            'panel' => [
//                'type' => GridView::TYPE_PRIMARY,
                'heading' => '<i class = "glyphicon glyphicon-book"></i> '
            ],
            'containerOptions' => ['style' => 'overflow: auto'], // only set when $responsive = false
            'headerRowOptions' => ['class' => 'text-center info'],
            'filterRowOptions' => ['class' => 'kartik-sheet-style'],
            'persistResize' => false,
            'beforeHeader' => [
                    [
                    'columns' => [
                            ['content' => 'PROGRAM/KEGIATAN/OUTPUT/SUBOUTPUT/<br>KOMPONEN/SUBKOMP/AKUN/DETIL', 'options' => ['colspan' => 2, 'class' => 'text-center info']],
                            ['content' => 'PERHITUNGAN TAHUN 2018', 'options' => ['colspan' => 4, 'class' => 'text-center info']],
                            ['content' => 'SERAPAN ANGGARAN', 'options' => ['colspan' => 14, 'class' => 'text-center info']],
                            ['content' => ' ', 'options' => ['colspan' => 1, 'class' => 'text-center info']],
                    ],
//                    'options' => ['class' => 'skip-export'] // remove this row from export
                ]
            ],
            'columns' => [
//                    ['class' => 'yii\grid\SerialColumn'],
//                'id',
//                'user_id',
//                'program',
//                'kegiatan',
//                'output',
//                'suboutput',
//                'komponen',
//                'subkomp',
                'kode',
                'uraian',
                'vol',
                'sat',
                    [
                    'attribute' => 'hargasat',
                    'value' => function($data) {
                        return 'Rp ' . number_format($data->hargasat, 0);
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'attribute' => 'jumlah',
                    'value' => function($data) {
                        return 'Rp ' . number_format($data->jumlah, 0);
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Januari',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '1');
                        if ($real == true) {
//                            print_r($real);
//                            die();
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Februari',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '2');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Maret',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '3');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'April',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '4');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Mei',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '5');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Juni',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '6');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Juli',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '7');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Agustus',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '8');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'September',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '9');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Oktober',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '10');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'November',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '11');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Desember',
                    'value' => function($data) {
                        $real = $data->databases($data->id, '12');
                        if ($real == true) {
                            return 'Rp ' . number_format($real, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Total',
                    'value' => function($data) {
                        $realis = (new \yii\db\Query())
                                ->select(['realisasi'])
                                ->from('diparealisasi')
                                ->where([
                                    'program' => $data->program,
                                    'kegiatan' => $data->kegiatan,
                                    'output' => $data->output,
                                    'suboutput' => $data->suboutput,
                                    'komponen' => $data->komponen,
                                    'subkomp' => $data->subkomp,
                                    'uraian' => $data->uraian,
                                ])
                                ->all();
                        if ($realis == true) {
                            for ($jumlah = 0; $jumlah < count($realis); $jumlah++) {
                                $a[$jumlah] = $realis[$jumlah][realisasi];
                            };
                            $uang = array_sum($a);
                            return 'Rp ' . number_format($uang, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Persentase',
                    'value' => function($data) {
                        $realis = (new \yii\db\Query())
                                ->select(['realisasi'])
                                ->from('diparealisasi')
                                ->where([
                                    'program' => $data->program,
                                    'kegiatan' => $data->kegiatan,
                                    'output' => $data->output,
                                    'suboutput' => $data->suboutput,
                                    'komponen' => $data->komponen,
                                    'subkomp' => $data->subkomp,
                                    'uraian' => $data->uraian,
                                ])
                                ->all();
                        $jum = (new \yii\db\Query())
                                ->select(['jumlah'])
                                ->from('dipa')
                                ->where([
                                    'program' => $data->program,
                                    'kegiatan' => $data->kegiatan,
                                    'output' => $data->output,
                                    'suboutput' => $data->suboutput,
                                    'komponen' => $data->komponen,
                                    'subkomp' => $data->subkomp,
                                    'uraian' => $data->uraian,
                                ])
                                ->all();
                        if ($realis == true) {
                            for ($jumlah = 0; $jumlah < count($realis); $jumlah++) {
                                $a[$jumlah] = $realis[$jumlah][realisasi];
                            };
                            $uang = array_sum($a);
                            return round($uang / $jum[0]['jumlah'] * 100, 2) . ' %';
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
                    [
                    'header' => 'Sisa',
                    'value' => function($data) {
                        $realis = (new \yii\db\Query())
                                ->select(['realisasi'])
                                ->from('diparealisasi')
                                ->where([
                                    'program' => $data->program,
                                    'kegiatan' => $data->kegiatan,
                                    'output' => $data->output,
                                    'suboutput' => $data->suboutput,
                                    'komponen' => $data->komponen,
                                    'subkomp' => $data->subkomp,
                                    'uraian' => $data->uraian,
                                ])
                                ->all();
                        $jum = (new \yii\db\Query())
                                ->select(['jumlah'])
                                ->from('dipa')
                                ->where([
                                    'program' => $data->program,
                                    'kegiatan' => $data->kegiatan,
                                    'output' => $data->output,
                                    'suboutput' => $data->suboutput,
                                    'komponen' => $data->komponen,
                                    'subkomp' => $data->subkomp,
                                    'uraian' => $data->uraian,
                                ])
                                ->all();
                        if ($realis == true) {
                            for ($jumlah = 0; $jumlah < count($realis); $jumlah++) {
                                $a[$jumlah] = $realis[$jumlah][realisasi];
                            };
                            $uang = array_sum($a);
                            return 'Rp ' . number_format($jum[0]['jumlah'] - $uang, 0);
                        } elseif ($data->hargasat == '0') {
                            return '';
                        }
                    },
                    'contentOptions' => ['class' => 'col-lg-1', 'style' => 'text-align: left;
        '],
                    'filter' => false,
                ],
            //'keterangan',
//                'bulan_id',
            //'timestamp',
//                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]);
        ?>
    </div>

    <?php
//echo Yii::$app->formatter->asCurrency(9912321.00, 'EUR',[\NumberFormatter::MAX_SIGNIFICANT_DIGITS=>100]);
    $this->registerJs('
        $("#inputcari").on("input", function(e){
        if($(this).data("lastval") != $(this).val()){
        $(this).data("lastval", $(this).val());
        //change action
        $("#buttoncari").attr("data-params", "{\"cari\":\""+$(this).val()+"\"}");
        };
        });
        $("#inputcari").keypress(function (e) {
        var key = e.which;
        if(key == 13)
        {
        $("#buttoncari").click();
        return false;
        }
        });
        '
    )
    ?>

</div>
<div class="diparealisasi-index">


</div>
